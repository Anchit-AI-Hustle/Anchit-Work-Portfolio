// /api/how-to-media — image-generation broker for /how-to-2.
// Uses OpenAI Images when configured; otherwise returns a deterministic SVG so
// the tutorial always has a real, downloadable visual package.

const IMAGE_MODEL = process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2';
const API_URL = 'https://api.openai.com/v1/images/generations';

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 'no-store');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });

  const body = typeof req.body === 'string' ? safeJson(req.body) : (req.body || {});
  const id = String(body.id || 'how-to-image').slice(0, 120);
  const kind = ['hero', 'infographic', 'step-image', 'checklist'].includes(body.kind) ? body.kind : 'step-image';
  const prompt = String(body.prompt || '').trim().slice(0, 12000);
  const altText = String(body.altText || prompt || 'Instructional visual').trim().slice(0, 500);
  const aspect = ['16:9', '9:16', '1:1'].includes(body.aspect) ? body.aspect : '16:9';
  if (!prompt) return res.status(400).json({ error: 'Missing image prompt' });

  const apiKey = process.env.OPENAI_API_KEY;
  if (apiKey) {
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          model: IMAGE_MODEL,
          prompt: productionPrompt(prompt, kind, altText),
          size: imageSize(aspect),
          quality: process.env.OPENAI_IMAGE_QUALITY || 'medium',
          output_format: 'webp',
          n: 1,
        }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload?.error?.message || `OpenAI Images ${response.status}`);
      const image = payload?.data?.[0];
      const url = image?.b64_json ? `data:image/webp;base64,${image.b64_json}` : image?.url;
      if (!url) throw new Error('The image provider returned no image bytes.');
      return res.status(200).json({ id, status: 'ready', url, provider: IMAGE_MODEL, fallback: false });
    } catch (error) {
      console.error('[how-to-media]', safeError(error));
    }
  }

  return res.status(200).json({
    id,
    status: 'ready',
    url: fallbackSvg(id, kind, altText, prompt, aspect),
    provider: 'deterministic-svg',
    fallback: true,
    warning: apiKey ? 'AI image generation failed; generated the deterministic visual fallback.' : 'OPENAI_API_KEY is not configured; generated the deterministic visual fallback.',
  });
};

function productionPrompt(prompt, kind, altText) {
  return [
    'Create a precise instructional visual, not decorative stock art.',
    `Asset type: ${kind}.`,
    `Instructional purpose: ${altText}.`,
    prompt,
    'Use one dominant visual focus, realistic object and hand geometry where applicable, clear spatial relationships, high contrast, clean background, and enough negative space for annotations.',
    'Do not add logos, watermarks, fake statistics, illegible text, medical claims, or invented interfaces. Do not depict a real identifiable person.',
  ].join(' ');
}

function imageSize(aspect) {
  if (aspect === '9:16') return '1024x1536';
  if (aspect === '1:1') return '1024x1024';
  return '1536x1024';
}

function fallbackSvg(id, kind, altText, prompt, aspect) {
  const dims = aspect === '9:16' ? [900, 1600] : aspect === '1:1' ? [1200, 1200] : [1600, 900];
  const width = dims[0];
  const height = dims[1];
  const seed = [...id].reduce((sum, char) => sum + char.charCodeAt(0), 0);
  const colors = ['#FF6940', '#FFB736', '#C9A96E', '#2EE5AC'];
  const accent = colors[seed % colors.length];
  const accent2 = colors[(seed + 1) % colors.length];
  const title = wrap(altText, Math.max(24, Math.round(width / 38)), 3);
  const detail = wrap(prompt, Math.max(38, Math.round(width / 26)), 4);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="title desc">
  <title id="title">${xml(altText)}</title><desc id="desc">${xml(prompt)}</desc>
  <defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#17130F"/><stop offset="1" stop-color="#050403"/></linearGradient><radialGradient id="glow"><stop stop-color="${accent}" stop-opacity=".42"/><stop offset="1" stop-color="${accent}" stop-opacity="0"/></radialGradient></defs>
  <rect width="${width}" height="${height}" rx="36" fill="url(#bg)"/>
  <circle cx="${Math.round(width * .78)}" cy="${Math.round(height * .36)}" r="${Math.round(Math.min(width, height) * .31)}" fill="url(#glow)"/>
  <circle cx="${Math.round(width * .78)}" cy="${Math.round(height * .36)}" r="${Math.round(Math.min(width, height) * .18)}" fill="${accent}" opacity=".1" stroke="${accent}" stroke-width="3"/>
  <path d="M${Math.round(width * .65)} ${Math.round(height * .36)}h${Math.round(width * .26)}M${Math.round(width * .78)} ${Math.round(height * .23)}v${Math.round(height * .26)}" stroke="${accent2}" stroke-width="2" stroke-dasharray="9 12"/>
  <text x="${Math.round(width * .065)}" y="${Math.round(height * .1)}" fill="${accent2}" font-family="Inter,Arial,sans-serif" font-size="${Math.round(width / 62)}" font-weight="800" letter-spacing="4">${xml(kind.toUpperCase())} · GENERATED FALLBACK</text>
  ${textLines(title, width * .065, height * .26, Math.max(42, width / 21), Math.max(50, width / 18), '#FBF5EC', 'Georgia,serif', 650)}
  ${textLines(detail, width * .067, height * .59, Math.max(20, width / 62), Math.max(30, width / 43), '#B7AFA4', 'Inter,Arial,sans-serif', 400)}
  <text x="${Math.round(width * .065)}" y="${Math.round(height * .92)}" fill="#7D756B" font-family="Inter,Arial,sans-serif" font-size="${Math.max(14, Math.round(width / 88))}">Production image can be regenerated when an image provider key is configured.</text>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function wrap(value, max, limit) {
  const words = String(value || '').trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let current = '';
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length > max && current) {
      lines.push(current);
      current = word;
      if (lines.length === limit - 1) break;
    } else current = next;
  }
  if (current && lines.length < limit) lines.push(current);
  if (lines.join(' ').length < String(value || '').trim().length && lines.length) lines[lines.length - 1] += '…';
  return lines;
}

function textLines(lines, x, y, size, lineHeight, color, family, weight) {
  return `<text x="${Math.round(x)}" y="${Math.round(y)}" fill="${color}" font-family="${family}" font-size="${Math.round(size)}" font-weight="${weight}">${lines.map((line, index) => `<tspan x="${Math.round(x)}" dy="${index ? Math.round(lineHeight) : 0}">${xml(line)}</tspan>`).join('')}</text>`;
}

function xml(value) {
  return String(value || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

function safeError(error) {
  return String(error?.message || error || 'Unknown media error').replace(/sk-[A-Za-z0-9_-]+/g, '[redacted]').slice(0, 600);
}

function safeJson(value) {
  try { return JSON.parse(value); } catch { return {}; }
}
